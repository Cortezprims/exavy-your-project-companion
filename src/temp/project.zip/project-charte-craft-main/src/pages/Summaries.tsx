import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useGemini } from "@/hooks/useGemini";
import { toast } from "sonner";
import {
  FileText,
  Loader2,
  Sparkles,
  Copy,
  Download,
  BookOpen,
  List,
  AlignLeft
} from "lucide-react";
import type { Json } from "@/integrations/supabase/types";

interface Summary {
  short: string;
  long: string;
  keyPoints: string[];
}

const Summaries = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeSummary, setActiveSummary] = useState<{ docId: string; content: Summary } | null>(null);
  const [summaryType, setSummaryType] = useState<'short' | 'long'>('short');

  const { generate, isLoading: isGenerating } = useGemini({
    model: 'gemini-1.5-pro',
    systemPrompt: `Tu es un expert en synthèse de documents. Crée des résumés clairs, structurés et pédagogiques.
    
Retourne UNIQUEMENT un JSON valide avec ce format exact:
{
  "short": "Résumé court (250 mots max)",
  "long": "Résumé détaillé (500+ mots)",
  "keyPoints": ["Point clé 1", "Point clé 2", "Point clé 3"]
}`,
  });

  const { data: documents = [] } = useQuery({
    queryKey: ['documents', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const { data: existingSummaries = [] } = useQuery({
    queryKey: ['summaries', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('study_materials')
        .select('*')
        .eq('user_id', user?.id)
        .eq('type', 'summary')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const saveSummary = useMutation({
    mutationFn: async (data: { docId: string; title: string; content: Summary }) => {
      const { error } = await supabase.from('study_materials').insert([{
        user_id: user?.id as string,
        doc_id: data.docId,
        title: `Résumé: ${data.title}`,
        type: 'summary' as const,
        content: data.content as unknown as Json,
      }]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['summaries'] });
      toast.success("Résumé sauvegardé");
    },
  });

  const generateSummary = async (doc: { id: string; title: string; extracted_content: string | null }) => {
    if (!doc.extracted_content) {
      toast.error("Ce document n'a pas de contenu extrait");
      return;
    }

    const prompt = `Génère un résumé complet de ce document:\n\n${doc.extracted_content.substring(0, 6000)}`;

    const result = await generate(prompt);
    if (!result) {
      toast.error("Erreur lors de la génération");
      return;
    }

    try {
      const jsonMatch = result.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("No JSON found");
      
      const parsed = JSON.parse(jsonMatch[0]) as Summary;
      
      setActiveSummary({ docId: doc.id, content: parsed });
      saveSummary.mutate({ docId: doc.id, title: doc.title, content: parsed });
    } catch (error) {
      console.error("Parse error:", error);
      toast.error("Erreur lors de la génération");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copié dans le presse-papier");
  };

  const openExistingSummary = (material: any) => {
    const content = material.content as Summary;
    setActiveSummary({ docId: material.doc_id, content });
  };

  if (activeSummary) {
    return (
      <MainLayout>
        <div className="p-6 md:p-8 max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button variant="ghost" onClick={() => setActiveSummary(null)}>
              ← Retour
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => copyToClipboard(
                summaryType === 'short' ? activeSummary.content.short : activeSummary.content.long
              )}>
                <Copy className="w-4 h-4 mr-2" />
                Copier
              </Button>
            </div>
          </div>

          <Tabs value={summaryType} onValueChange={(v) => setSummaryType(v as 'short' | 'long')}>
            <TabsList className="mb-6">
              <TabsTrigger value="short">
                <AlignLeft className="w-4 h-4 mr-2" />
                Résumé court
              </TabsTrigger>
              <TabsTrigger value="long">
                <BookOpen className="w-4 h-4 mr-2" />
                Résumé détaillé
              </TabsTrigger>
            </TabsList>

            <Card className="mb-6">
              <CardContent className="p-6">
                <TabsContent value="short" className="mt-0">
                  <p className="text-lg leading-relaxed whitespace-pre-wrap">
                    {activeSummary.content.short}
                  </p>
                </TabsContent>
                <TabsContent value="long" className="mt-0">
                  <p className="text-lg leading-relaxed whitespace-pre-wrap">
                    {activeSummary.content.long}
                  </p>
                </TabsContent>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <List className="w-5 h-5" />
                  Points clés
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {activeSummary.content.keyPoints.map((point, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <Badge variant="secondary" className="mt-0.5">{i + 1}</Badge>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </Tabs>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="p-6 md:p-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Résumés Intelligents</h1>
          <p className="text-muted-foreground">Générez des synthèses claires et structurées</p>
        </div>

        {/* Existing summaries */}
        {existingSummaries.length > 0 && (
          <div className="mb-8">
            <h2 className="font-semibold text-lg mb-4">Mes résumés</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {existingSummaries.map((material) => (
                <Card
                  key={material.id}
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => openExistingSummary(material)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Sparkles className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium truncate">{material.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {new Date(material.created_at || '').toLocaleDateString('fr-FR')}
                        </p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Voir le résumé
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Generate from documents */}
        <div>
          <h2 className="font-semibold text-lg mb-4">Générer depuis un document</h2>
          {documents.length === 0 ? (
            <Card className="text-center py-8">
              <CardContent>
                <FileText className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
                <p className="text-muted-foreground">Importez des documents pour créer des résumés</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {documents.map((doc) => (
                <Card key={doc.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium truncate">{doc.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {doc.processing_status === 'completed' ? 'Prêt' : 'En traitement...'}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => generateSummary(doc)}
                      disabled={isGenerating || doc.processing_status !== 'completed'}
                    >
                      {isGenerating ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Sparkles className="w-4 h-4 mr-2" />
                      )}
                      Générer un résumé
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
};

export default Summaries;
