import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useGemini } from "@/hooks/useGemini";
import { toast } from "sonner";
import { format, differenceInDays, addDays } from "date-fns";
import { fr } from "date-fns/locale";
import {
  Calendar,
  Clock,
  Target,
  Plus,
  Loader2,
  CheckCircle2,
  Circle,
  XCircle,
  Sparkles,
  BookOpen,
  Trash2
} from "lucide-react";
import type { Json } from "@/integrations/supabase/types";

interface StudySession {
  date: string;
  subject: string;
  duration: number;
  status: 'pending' | 'completed' | 'missed';
}

interface StudyPlan {
  id: string;
  exam_name: string;
  exam_date: string;
  subjects: string[];
  daily_time_available: number;
  schedule: StudySession[];
}

const Planning = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [examName, setExamName] = useState("");
  const [examDate, setExamDate] = useState("");
  const [subjects, setSubjects] = useState("");
  const [dailyTime, setDailyTime] = useState(60);

  const { generate, isLoading: isGenerating } = useGemini({
    model: 'gemini-1.5-pro',
    systemPrompt: `Tu es un expert en planification d'études. Crée des plannings de révision optimisés basés sur la courbe d'oubli d'Ebbinghaus.
    
Retourne UNIQUEMENT un JSON valide avec ce format:
{
  "sessions": [
    {
      "date": "2024-01-15",
      "subject": "Mathématiques",
      "duration": 45
    }
  ]
}`,
  });

  const { data: studyPlans = [] } = useQuery({
    queryKey: ['study-plans', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('study_plans')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []).map(p => ({
        ...p,
        schedule: (p.schedule || []) as unknown as StudySession[],
      })) as StudyPlan[];
    },
    enabled: !!user?.id,
  });

  const createPlan = useMutation({
    mutationFn: async (plan: Omit<StudyPlan, 'id'>) => {
      const { error } = await supabase.from('study_plans').insert([{
        user_id: user?.id as string,
        exam_name: plan.exam_name,
        exam_date: plan.exam_date,
        subjects: plan.subjects,
        daily_time_available: plan.daily_time_available,
        schedule: plan.schedule as unknown as Json,
      }]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['study-plans'] });
      toast.success("Planning créé avec succès");
      setShowCreate(false);
      resetForm();
    },
  });

  const deletePlan = useMutation({
    mutationFn: async (planId: string) => {
      const { error } = await supabase
        .from('study_plans')
        .delete()
        .eq('id', planId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['study-plans'] });
      toast.success("Planning supprimé");
    },
  });

  const updateSession = useMutation({
    mutationFn: async ({ planId, sessionIndex, status }: { planId: string; sessionIndex: number; status: 'completed' | 'missed' }) => {
      const plan = studyPlans.find(p => p.id === planId);
      if (!plan) return;

      const updatedSchedule = [...(plan.schedule || [])];
      updatedSchedule[sessionIndex] = { ...updatedSchedule[sessionIndex], status };

      const { error } = await supabase
        .from('study_plans')
        .update({ schedule: updatedSchedule as unknown as Json })
        .eq('id', planId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['study-plans'] });
    },
  });

  const resetForm = () => {
    setExamName("");
    setExamDate("");
    setSubjects("");
    setDailyTime(60);
  };

  const handleCreatePlan = async () => {
    if (!examName || !examDate || !subjects) {
      toast.error("Veuillez remplir tous les champs");
      return;
    }

    const subjectList = subjects.split(',').map(s => s.trim()).filter(Boolean);
    const daysUntilExam = differenceInDays(new Date(examDate), new Date());

    if (daysUntilExam < 1) {
      toast.error("La date d'examen doit être dans le futur");
      return;
    }

    const prompt = `Crée un planning de révision pour:
- Examen: ${examName}
- Jours restants: ${daysUntilExam}
- Matières: ${subjectList.join(', ')}
- Temps disponible par jour: ${dailyTime} minutes

Génère ${Math.min(daysUntilExam, 30)} sessions de révision optimisées selon la répétition espacée.
Les dates doivent être au format YYYY-MM-DD, commençant demain.`;

    const result = await generate(prompt);
    if (!result) {
      toast.error("Erreur lors de la génération");
      return;
    }

    try {
      const jsonMatch = result.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("No JSON found");
      
      const parsed = JSON.parse(jsonMatch[0]);
      const sessions: StudySession[] = parsed.sessions.map((s: any) => ({
        ...s,
        status: 'pending' as const,
      }));

      createPlan.mutate({
        exam_name: examName,
        exam_date: examDate,
        subjects: subjectList,
        daily_time_available: dailyTime,
        schedule: sessions,
      } as any);
    } catch (error) {
      console.error("Parse error:", error);
      toast.error("Erreur lors de la création du planning");
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'missed': return <XCircle className="w-5 h-5 text-destructive" />;
      default: return <Circle className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const calculateProgress = (schedule: StudySession[]) => {
    if (!schedule || schedule.length === 0) return 0;
    const completed = schedule.filter(s => s.status === 'completed').length;
    return Math.round((completed / schedule.length) * 100);
  };

  return (
    <MainLayout>
      <div className="p-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">Planning Dynamique</h1>
            <p className="text-muted-foreground">Planifiez vos révisions intelligemment</p>
          </div>
          <Button onClick={() => setShowCreate(!showCreate)}>
            <Plus className="w-4 h-4 mr-2" />
            Nouveau planning
          </Button>
        </div>

        {/* Create form */}
        {showCreate && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Créer un planning de révision
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nom de l'examen</Label>
                  <Input
                    value={examName}
                    onChange={(e) => setExamName(e.target.value)}
                    placeholder="Ex: Baccalauréat, Examen final..."
                  />
                </div>
                <div className="space-y-2">
                  <Label>Date de l'examen</Label>
                  <Input
                    type="date"
                    value={examDate}
                    onChange={(e) => setExamDate(e.target.value)}
                    min={format(addDays(new Date(), 1), 'yyyy-MM-dd')}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Matières (séparées par des virgules)</Label>
                <Input
                  value={subjects}
                  onChange={(e) => setSubjects(e.target.value)}
                  placeholder="Ex: Mathématiques, Physique, Histoire..."
                />
              </div>
              <div className="space-y-2">
                <Label>Temps disponible par jour (minutes)</Label>
                <Input
                  type="number"
                  value={dailyTime}
                  onChange={(e) => setDailyTime(parseInt(e.target.value) || 60)}
                  min={15}
                  max={480}
                />
              </div>
              <div className="flex gap-3">
                <Button onClick={handleCreatePlan} disabled={isGenerating}>
                  {isGenerating ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4 mr-2" />
                  )}
                  Générer le planning
                </Button>
                <Button variant="outline" onClick={() => { setShowCreate(false); resetForm(); }}>
                  Annuler
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Existing plans */}
        {studyPlans.length === 0 && !showCreate ? (
          <Card className="text-center py-12">
            <CardContent>
              <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-semibold text-lg mb-2">Aucun planning</h3>
              <p className="text-muted-foreground mb-4">
                Créez votre premier planning de révision intelligent
              </p>
              <Button onClick={() => setShowCreate(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Créer un planning
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {studyPlans.map((plan) => {
              const daysLeft = differenceInDays(new Date(plan.exam_date), new Date());
              const progress = calculateProgress(plan.schedule || []);
              const schedule = plan.schedule || [];

              return (
                <Card key={plan.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Target className="w-5 h-5" />
                          {plan.exam_name}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">
                          {daysLeft > 0 ? `${daysLeft} jours restants` : "Examen passé"} • 
                          {format(new Date(plan.exam_date), ' d MMMM yyyy', { locale: fr })}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deletePlan.mutate(plan.id)}
                      >
                        <Trash2 className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {/* Progress */}
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Progression</span>
                        <span className="text-sm text-muted-foreground">{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>

                    {/* Subjects */}
                    <div className="flex flex-wrap gap-2 mb-6">
                      {plan.subjects?.map((subject, i) => (
                        <Badge key={i} variant="secondary">
                          <BookOpen className="w-3 h-3 mr-1" />
                          {subject}
                        </Badge>
                      ))}
                    </div>

                    {/* Schedule */}
                    <div className="space-y-2">
                      <h4 className="font-medium mb-3">Sessions de révision</h4>
                      <div className="grid gap-2 max-h-[300px] overflow-y-auto">
                        {schedule.slice(0, 10).map((session, i) => (
                          <div
                            key={i}
                            className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                          >
                            <div className="flex items-center gap-3">
                              {getStatusIcon(session.status)}
                              <div>
                                <p className="font-medium">{session.subject}</p>
                                <p className="text-sm text-muted-foreground">
                                  {format(new Date(session.date), 'd MMMM', { locale: fr })} • {session.duration} min
                                </p>
                              </div>
                            </div>
                            {session.status === 'pending' && (
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => updateSession.mutate({ planId: plan.id, sessionIndex: i, status: 'completed' })}
                                >
                                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => updateSession.mutate({ planId: plan.id, sessionIndex: i, status: 'missed' })}
                                >
                                  <XCircle className="w-4 h-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </div>
                        ))}
                        {schedule.length > 10 && (
                          <p className="text-sm text-muted-foreground text-center py-2">
                            +{schedule.length - 10} autres sessions
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Planning;
