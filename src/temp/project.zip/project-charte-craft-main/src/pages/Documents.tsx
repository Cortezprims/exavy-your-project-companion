import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useDropzone } from "react-dropzone";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  FileText,
  Upload,
  Image,
  Mic,
  FileType,
  Search,
  Trash2,
  Eye,
  Brain,
  BookOpen,
  MessageSquare,
  MoreVertical,
  Loader2
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const Documents = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['documents', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const deleteDocument = useMutation({
    mutationFn: async (docId: string) => {
      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', docId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      toast.success("Document supprimé");
    },
    onError: () => {
      toast.error("Erreur lors de la suppression");
    },
  });

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!user) return;

    setIsUploading(true);
    for (const file of acceptedFiles) {
      try {
        const fileExt = file.name.split('.').pop()?.toLowerCase();
        let fileType: 'pdf' | 'audio' | 'image' | 'text' = 'text';
        
        if (fileExt === 'pdf') fileType = 'pdf';
        else if (['mp3', 'm4a', 'wav'].includes(fileExt || '')) fileType = 'audio';
        else if (['jpg', 'jpeg', 'png'].includes(fileExt || '')) fileType = 'image';

        // Upload to storage
        const filePath = `${user.id}/${Date.now()}_${file.name}`;
        const { error: uploadError } = await supabase.storage
          .from('documents')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('documents')
          .getPublicUrl(filePath);

        // Create document record
        const { data: docData, error: insertError } = await supabase
          .from('documents')
          .insert({
            user_id: user.id,
            title: file.name,
            file_type: fileType,
            file_url: urlData.publicUrl,
            file_size: file.size,
            processing_status: 'pending',
          })
          .select()
          .single();

        if (insertError) throw insertError;

        toast.success(`${file.name} importé - extraction du texte en cours...`);

        // Trigger text extraction in background
        supabase.functions.invoke('extract-text', {
          body: {
            documentId: docData.id,
            fileUrl: urlData.publicUrl,
            fileType: fileType,
          },
        }).then(({ error }) => {
          if (error) {
            console.error('Text extraction error:', error);
            toast.error(`Erreur d'extraction pour ${file.name}`);
          } else {
            toast.success(`Texte extrait de ${file.name}`);
            queryClient.invalidateQueries({ queryKey: ['documents'] });
          }
        });

      } catch (error) {
        console.error(error);
        toast.error(`Erreur lors de l'import de ${file.name}`);
      }
    }
    setIsUploading(false);
    queryClient.invalidateQueries({ queryKey: ['documents'] });
  }, [user, queryClient]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpg', '.jpeg', '.png'],
      'audio/*': ['.mp3', '.m4a', '.wav'],
      'text/plain': ['.txt'],
    },
    maxSize: 100 * 1024 * 1024, // 100MB
  });

  const filteredDocuments = documents.filter(doc =>
    doc.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf': return <FileText className="w-5 h-5 text-destructive" />;
      case 'image': return <Image className="w-5 h-5 text-primary" />;
      case 'audio': return <Mic className="w-5 h-5 text-secondary" />;
      default: return <FileType className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return 'N/A';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <MainLayout>
      <div className="p-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">Documents</h1>
            <p className="text-muted-foreground">Importez et gérez vos documents d'étude</p>
          </div>
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Upload zone */}
        <Card
          {...getRootProps()}
          className={`mb-8 border-2 border-dashed cursor-pointer transition-all ${
            isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
          }`}
        >
          <input {...getInputProps()} />
          <CardContent className="py-12 text-center">
            {isUploading ? (
              <Loader2 className="w-12 h-12 mx-auto mb-4 text-primary animate-spin" />
            ) : (
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            )}
            <h3 className="font-medium text-lg mb-2">
              {isDragActive ? "Déposez les fichiers ici" : "Glissez-déposez vos fichiers"}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              ou cliquez pour parcourir
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <Badge variant="secondary">PDF (max 50 MB)</Badge>
              <Badge variant="secondary">Images (max 10 MB)</Badge>
              <Badge variant="secondary">Audio (max 100 MB)</Badge>
              <Badge variant="secondary">Texte</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Documents list */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredDocuments.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-medium text-lg mb-2">Aucun document</h3>
              <p className="text-sm text-muted-foreground">
                Importez votre premier document pour commencer
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredDocuments.map((doc) => (
              <Card key={doc.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center flex-shrink-0">
                      {getFileIcon(doc.file_type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{doc.title}</h4>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{formatFileSize(doc.file_size)}</span>
                        <span>•</span>
                        <span>
                          {format(new Date(doc.created_at!), "d MMM yyyy", { locale: fr })}
                        </span>
                        {doc.processing_status === 'pending' && (
                          <Badge variant="secondary" className="ml-2">
                            <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                            Traitement
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        title="Voir"
                        onClick={() => doc.file_url && window.open(doc.file_url, '_blank')}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        title="Quiz"
                        onClick={() => navigate(`/quiz?docId=${doc.id}`)}
                      >
                        <Brain className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        title="Flashcards"
                        onClick={() => navigate(`/flashcards?docId=${doc.id}`)}
                      >
                        <BookOpen className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        title="Chat"
                        onClick={() => navigate(`/chat?docId=${doc.id}`)}
                      >
                        <MessageSquare className="w-4 h-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => deleteDocument.mutate(doc.id)}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Supprimer
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Documents;
