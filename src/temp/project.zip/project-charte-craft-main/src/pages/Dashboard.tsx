import { useAuth } from "@/hooks/useAuth";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, FileText, Brain, Calendar, LogOut, User } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const quickActions = [
    {
      icon: FileText,
      title: "Importer un document",
      description: "PDF, audio, image ou texte",
      path: "/documents",
      iconWrapClass: "bg-primary text-primary-foreground",
    },
    {
      icon: Brain,
      title: "Réviser",
      description: "Flashcards et quiz",
      path: "/flashcards",
      iconWrapClass: "bg-secondary text-secondary-foreground",
    },
    {
      icon: Calendar,
      title: "Planning",
      description: "Organiser vos sessions",
      path: "/planning",
      iconWrapClass: "bg-accent text-accent-foreground",
    },
  ];

  return (
    <MainLayout>
      <div className="min-h-screen">
        <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-border">
          <nav className="container mx-auto px-6 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-xl text-foreground">EXAVY</span>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                <User className="w-4 h-4" />
                <span className="truncate max-w-[220px]">{user?.email}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={handleSignOut}>
                <LogOut className="w-4 h-4 mr-2" />
                Déconnexion
              </Button>
            </div>
          </nav>
        </header>

        <main className="container mx-auto px-6 py-8">
          <section className="mb-8">
            <h1 className="font-display text-3xl font-bold text-foreground mb-2">Bienvenue sur EXAVY</h1>
            <p className="text-muted-foreground">Commencez par importer un document ou explorez vos outils.</p>
          </section>

          <section className="grid md:grid-cols-3 gap-6 mb-8" aria-label="Actions rapides">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Card
                  key={action.path}
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate(action.path)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") navigate(action.path);
                  }}
                  className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-[1.02] border-2 hover:border-primary/50"
                >
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-xl ${action.iconWrapClass} flex items-center justify-center mb-2`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <CardTitle className="text-lg">{action.title}</CardTitle>
                    <CardDescription>{action.description}</CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </section>

          <section className="grid md:grid-cols-4 gap-4 mb-8" aria-label="Statistiques">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-foreground">0</div>
                <p className="text-sm text-muted-foreground">Documents</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-foreground">0</div>
                <p className="text-sm text-muted-foreground">Quiz complétés</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-foreground">0</div>
                <p className="text-sm text-muted-foreground">Flashcards révisées</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-foreground">0</div>
                <p className="text-sm text-muted-foreground">Jours de série</p>
              </CardContent>
            </Card>
          </section>

          <section aria-label="Démarrage">
            <Card className="text-center py-12">
              <CardContent>
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-8 h-8 text-muted-foreground" />
                </div>
                <h2 className="font-display font-semibold text-xl text-foreground mb-2">Aucun document</h2>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Importez votre premier document pour générer des quiz, flashcards et résumés.
                </p>
                <Button onClick={() => navigate("/documents")}>
                  <FileText className="w-4 h-4 mr-2" />
                  Importer un document
                </Button>
              </CardContent>
            </Card>
          </section>
        </main>
      </div>
    </MainLayout>
  );
};

export default Dashboard;

