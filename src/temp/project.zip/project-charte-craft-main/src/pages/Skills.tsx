import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Target,
  Award,
  BookOpen,
  Brain,
  Lightbulb,
  GraduationCap
} from "lucide-react";

const Skills = () => {
  const { user } = useAuth();

  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const { data: quizResults = [] } = useQuery({
    queryKey: ['quiz-results', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('quiz_results')
        .select('*')
        .eq('user_id', user?.id)
        .order('completed_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const { data: srsLogs = [] } = useQuery({
    queryKey: ['srs-logs', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('srs_logs')
        .select('*')
        .eq('user_id', user?.id);
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Calculate stats
  const totalQuizzes = quizResults.length;
  const avgScore = totalQuizzes > 0
    ? Math.round(quizResults.reduce((sum, r) => sum + (r.score || 0), 0) / totalQuizzes)
    : 0;
  const totalFlashcards = srsLogs.length;
  const masteredCards = srsLogs.filter(l => (l.ease_factor || 0) >= 3).length;

  // Performance data for charts
  const performanceData = [
    { subject: "Quiz", score: avgScore, fullMark: 100 },
    { subject: "Flashcards", score: totalFlashcards > 0 ? Math.round((masteredCards / totalFlashcards) * 100) : 0, fullMark: 100 },
    { subject: "Documents", score: Math.min((profile?.documents_uploaded || 0) * 10, 100), fullMark: 100 },
    { subject: "Régularité", score: Math.min((profile?.streak_days || 0) * 10, 100), fullMark: 100 },
  ];

  const weeklyData = [
    { day: "Lun", minutes: 45 },
    { day: "Mar", minutes: 60 },
    { day: "Mer", minutes: 30 },
    { day: "Jeu", minutes: 75 },
    { day: "Ven", minutes: 50 },
    { day: "Sam", minutes: 20 },
    { day: "Dim", minutes: 40 },
  ];

  const strengths = [
    { skill: "Mémorisation", level: 85, trend: 'up' },
    { skill: "Compréhension", level: 78, trend: 'up' },
    { skill: "Analyse", level: 72, trend: 'stable' },
    { skill: "Synthèse", level: 65, trend: 'down' },
  ];

  const recommendations = [
    {
      icon: Brain,
      title: "Pratiquez la répétition espacée",
      description: "Révisez vos flashcards quotidiennement pour améliorer la rétention à long terme.",
    },
    {
      icon: BookOpen,
      title: "Diversifiez vos sources",
      description: "Importez plus de documents variés pour enrichir votre apprentissage.",
    },
    {
      icon: Target,
      title: "Fixez des objectifs quotidiens",
      description: "Définissez un temps d'étude minimum chaque jour pour maintenir votre régularité.",
    },
  ];

  return (
    <MainLayout>
      <div className="p-6 md:p-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">Profil de Compétences</h1>
          <p className="text-muted-foreground">Analysez vos performances et identifiez vos axes d'amélioration</p>
        </div>

        {/* Stats cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Score moyen</p>
                  <p className="text-2xl font-bold">{avgScore}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-secondary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Quiz complétés</p>
                  <p className="text-2xl font-bold">{totalQuizzes}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Brain className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Cartes maîtrisées</p>
                  <p className="text-2xl font-bold">{masteredCards}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
                  <Target className="w-5 h-5 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Série actuelle</p>
                  <p className="text-2xl font-bold">{profile?.streak_days || 0} jours</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Radar chart */}
          <Card>
            <CardHeader>
              <CardTitle>Vue d'ensemble des compétences</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={performanceData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} />
                    <Radar
                      name="Score"
                      dataKey="score"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.3}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Weekly activity */}
          <Card>
            <CardHeader>
              <CardTitle>Activité de la semaine</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="minutes" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Strengths */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Points forts & axes d'amélioration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {strengths.map((item, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{item.skill}</span>
                      {item.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-500" />}
                      {item.trend === 'down' && <TrendingDown className="w-4 h-4 text-destructive" />}
                    </div>
                    <Badge variant={item.level >= 80 ? "default" : item.level >= 60 ? "secondary" : "outline"}>
                      {item.level}%
                    </Badge>
                  </div>
                  <Progress value={item.level} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Recommandations personnalisées
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recommendations.map((rec, i) => {
                const Icon = rec.icon;
                return (
                  <div key={i} className="flex gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">{rec.title}</h4>
                      <p className="text-sm text-muted-foreground">{rec.description}</p>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default Skills;
