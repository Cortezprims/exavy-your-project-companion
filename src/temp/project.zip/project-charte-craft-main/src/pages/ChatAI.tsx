import { useState, useRef, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useGemini } from "@/hooks/useGemini";
import { toast } from "sonner";
import {
  MessageSquare,
  Send,
  FileText,
  Loader2,
  Bot,
  User,
  Sparkles,
  Volume2,
  Copy
} from "lucide-react";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const ChatAI = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const docIdFromUrl = searchParams.get('docId');
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { generate, isLoading } = useGemini({
    model: 'gemini-1.5-flash',
    systemPrompt: `Tu es un assistant éducatif intelligent. Tu réponds aux questions des utilisateurs sur leurs documents de manière claire, concise et pédagogique. Cite les passages pertinents du document quand c'est utile.`,
  });

  const { data: documents = [] } = useQuery({
    queryKey: ['documents', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Auto-select document when coming from a document page
  useEffect(() => {
    if (docIdFromUrl && documents.length > 0 && !selectedDoc) {
      const doc = documents.find(d => d.id === docIdFromUrl);
      if (doc) {
        setSelectedDoc(doc.id);
      }
    }
  }, [docIdFromUrl, documents, selectedDoc]);

  const selectedDocument = documents.find(d => d.id === selectedDoc);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Réponse copiée");
    } catch {
      toast.error("Impossible de copier");
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");

    const context = selectedDocument?.extracted_content 
      ? `Contexte du document "${selectedDocument.title}":\n${selectedDocument.extracted_content.substring(0, 4000)}\n\n`
      : "";

    const prompt = `${context}Question de l'utilisateur: ${input}`;

    const response = await generate(prompt);
    
    if (response) {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
    } else {
      toast.error("Erreur lors de la génération de la réponse");
    }
  };

  const suggestedQuestions = [
    "Résume les points clés de ce document",
    "Quels sont les concepts les plus importants ?",
    "Explique-moi ce sujet simplement",
    "Génère des questions de révision",
  ];

  return (
    <MainLayout>
      <div className="flex h-[calc(100vh-4rem)]">
        {/* Sidebar documents */}
        <div className="w-64 border-r bg-muted/30 p-4 hidden md:block">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Documents
          </h3>
          <div className="space-y-2">
            <Button
              variant={selectedDoc === null ? "secondary" : "ghost"}
              size="sm"
              className="w-full justify-start"
              onClick={() => setSelectedDoc(null)}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Chat général
            </Button>
            {documents.map(doc => (
              <Button
                key={doc.id}
                variant={selectedDoc === doc.id ? "secondary" : "ghost"}
                size="sm"
                className="w-full justify-start truncate"
                onClick={() => setSelectedDoc(doc.id)}
              >
                <FileText className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">{doc.title}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="border-b p-4 bg-background">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold">Assistant EXAVY</h2>
                <p className="text-sm text-muted-foreground">
                  {selectedDocument ? `Document: ${selectedDocument.title}` : "Chat général"}
                </p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <MessageSquare className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Posez votre question</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  {selectedDocument 
                    ? `Posez des questions sur "${selectedDocument.title}"`
                    : "Sélectionnez un document ou discutez librement"}
                </p>
                <div className="flex flex-wrap gap-2 justify-center max-w-lg">
                  {suggestedQuestions.map((q, i) => (
                    <Badge
                      key={i}
                      variant="secondary"
                      className="cursor-pointer hover:bg-primary/20"
                      onClick={() => setInput(q)}
                    >
                      {q}
                    </Badge>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map(msg => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.role === 'assistant' && (
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Bot className="w-4 h-4 text-primary" />
                      </div>
                    )}
                    <Card className={`max-w-[70%] ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : ''}`}>
                      <CardContent className="p-3">
                        <div className="flex items-start gap-2">
                          <p className="whitespace-pre-wrap flex-1">{msg.content}</p>
                          {msg.role === 'assistant' && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              title="Copier la réponse"
                              onClick={() => handleCopy(msg.content)}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                    {msg.role === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Bot className="w-4 h-4 text-primary" />
                    </div>
                    <Card>
                      <CardContent className="p-3">
                        <Loader2 className="w-5 h-5 animate-spin" />
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            )}
          </ScrollArea>

          {/* Input */}
          <div className="border-t p-4 bg-background">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Posez votre question..."
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
                disabled={isLoading}
              />
              <Button onClick={handleSend} disabled={isLoading || !input.trim()}>
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ChatAI;
