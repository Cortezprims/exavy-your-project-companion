export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      chat_history: {
        Row: {
          created_at: string | null
          doc_id: string | null
          id: string
          messages: Json | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          doc_id?: string | null
          id?: string
          messages?: Json | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          doc_id?: string | null
          id?: string
          messages?: Json | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_history_doc_id_fkey"
            columns: ["doc_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          created_at: string | null
          extracted_content: string | null
          file_size: number | null
          file_type: Database["public"]["Enums"]["file_type"]
          file_url: string | null
          id: string
          language: string | null
          processing_status:
            | Database["public"]["Enums"]["processing_status"]
            | null
          summary_text: string | null
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          extracted_content?: string | null
          file_size?: number | null
          file_type: Database["public"]["Enums"]["file_type"]
          file_url?: string | null
          id?: string
          language?: string | null
          processing_status?:
            | Database["public"]["Enums"]["processing_status"]
            | null
          summary_text?: string | null
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          extracted_content?: string | null
          file_size?: number | null
          file_type?: Database["public"]["Enums"]["file_type"]
          file_url?: string | null
          id?: string
          language?: string | null
          processing_status?:
            | Database["public"]["Enums"]["processing_status"]
            | null
          summary_text?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          account_type: Database["public"]["Enums"]["account_type"] | null
          created_at: string | null
          daily_goal_minutes: number | null
          display_name: string | null
          documents_uploaded: number | null
          education_level: string | null
          email: string | null
          flashcards_reviewed: number | null
          id: string
          language: string | null
          last_login: string | null
          notifications_enabled: boolean | null
          quiz_completed: number | null
          streak_days: number | null
          stripe_customer_id: string | null
          subscription_ends_at: string | null
          subscription_plan:
            | Database["public"]["Enums"]["subscription_plan"]
            | null
          subscription_status:
            | Database["public"]["Enums"]["subscription_status"]
            | null
          theme: string | null
          total_study_time: number | null
          trial_ends_at: string | null
        }
        Insert: {
          account_type?: Database["public"]["Enums"]["account_type"] | null
          created_at?: string | null
          daily_goal_minutes?: number | null
          display_name?: string | null
          documents_uploaded?: number | null
          education_level?: string | null
          email?: string | null
          flashcards_reviewed?: number | null
          id: string
          language?: string | null
          last_login?: string | null
          notifications_enabled?: boolean | null
          quiz_completed?: number | null
          streak_days?: number | null
          stripe_customer_id?: string | null
          subscription_ends_at?: string | null
          subscription_plan?:
            | Database["public"]["Enums"]["subscription_plan"]
            | null
          subscription_status?:
            | Database["public"]["Enums"]["subscription_status"]
            | null
          theme?: string | null
          total_study_time?: number | null
          trial_ends_at?: string | null
        }
        Update: {
          account_type?: Database["public"]["Enums"]["account_type"] | null
          created_at?: string | null
          daily_goal_minutes?: number | null
          display_name?: string | null
          documents_uploaded?: number | null
          education_level?: string | null
          email?: string | null
          flashcards_reviewed?: number | null
          id?: string
          language?: string | null
          last_login?: string | null
          notifications_enabled?: boolean | null
          quiz_completed?: number | null
          streak_days?: number | null
          stripe_customer_id?: string | null
          subscription_ends_at?: string | null
          subscription_plan?:
            | Database["public"]["Enums"]["subscription_plan"]
            | null
          subscription_status?:
            | Database["public"]["Enums"]["subscription_status"]
            | null
          theme?: string | null
          total_study_time?: number | null
          trial_ends_at?: string | null
        }
        Relationships: []
      }
      quiz_results: {
        Row: {
          answers: Json | null
          completed_at: string | null
          correct_answers: number
          id: string
          quiz_id: string | null
          score: number
          time_taken: number | null
          total_questions: number
          user_id: string
        }
        Insert: {
          answers?: Json | null
          completed_at?: string | null
          correct_answers: number
          id?: string
          quiz_id?: string | null
          score: number
          time_taken?: number | null
          total_questions: number
          user_id: string
        }
        Update: {
          answers?: Json | null
          completed_at?: string | null
          correct_answers?: number
          id?: string
          quiz_id?: string | null
          score?: number
          time_taken?: number | null
          total_questions?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "quiz_results_quiz_id_fkey"
            columns: ["quiz_id"]
            isOneToOne: false
            referencedRelation: "study_materials"
            referencedColumns: ["id"]
          },
        ]
      }
      srs_logs: {
        Row: {
          card_id: string
          created_at: string | null
          ease_factor: number | null
          id: string
          interval_days: number | null
          last_review: string | null
          material_id: string | null
          next_review: string | null
          quality: number | null
          repetitions: number | null
          user_id: string
        }
        Insert: {
          card_id: string
          created_at?: string | null
          ease_factor?: number | null
          id?: string
          interval_days?: number | null
          last_review?: string | null
          material_id?: string | null
          next_review?: string | null
          quality?: number | null
          repetitions?: number | null
          user_id: string
        }
        Update: {
          card_id?: string
          created_at?: string | null
          ease_factor?: number | null
          id?: string
          interval_days?: number | null
          last_review?: string | null
          material_id?: string | null
          next_review?: string | null
          quality?: number | null
          repetitions?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "srs_logs_material_id_fkey"
            columns: ["material_id"]
            isOneToOne: false
            referencedRelation: "study_materials"
            referencedColumns: ["id"]
          },
        ]
      }
      study_materials: {
        Row: {
          content: Json
          created_at: string | null
          doc_id: string | null
          id: string
          title: string
          type: Database["public"]["Enums"]["material_type"]
          user_id: string
        }
        Insert: {
          content?: Json
          created_at?: string | null
          doc_id?: string | null
          id?: string
          title: string
          type: Database["public"]["Enums"]["material_type"]
          user_id: string
        }
        Update: {
          content?: Json
          created_at?: string | null
          doc_id?: string | null
          id?: string
          title?: string
          type?: Database["public"]["Enums"]["material_type"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "study_materials_doc_id_fkey"
            columns: ["doc_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      study_plans: {
        Row: {
          created_at: string | null
          daily_time_available: number | null
          exam_date: string
          exam_name: string
          id: string
          schedule: Json | null
          subjects: string[] | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          daily_time_available?: number | null
          exam_date: string
          exam_name: string
          id?: string
          schedule?: Json | null
          subjects?: string[] | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          daily_time_available?: number | null
          exam_date?: string
          exam_name?: string
          id?: string
          schedule?: Json | null
          subjects?: string[] | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_premium: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      account_type: "student" | "professional" | "teacher"
      app_role: "admin" | "moderator" | "user"
      card_status: "new" | "learning" | "reviewing" | "mastered"
      file_type: "pdf" | "audio" | "image" | "text"
      material_type: "quiz" | "flashcard_deck" | "mindmap" | "summary"
      processing_status: "pending" | "completed" | "failed"
      session_status: "pending" | "completed" | "missed"
      subscription_plan: "monthly" | "yearly"
      subscription_status: "free" | "trial" | "premium"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      account_type: ["student", "professional", "teacher"],
      app_role: ["admin", "moderator", "user"],
      card_status: ["new", "learning", "reviewing", "mastered"],
      file_type: ["pdf", "audio", "image", "text"],
      material_type: ["quiz", "flashcard_deck", "mindmap", "summary"],
      processing_status: ["pending", "completed", "failed"],
      session_status: ["pending", "completed", "missed"],
      subscription_plan: ["monthly", "yearly"],
      subscription_status: ["free", "trial", "premium"],
    },
  },
} as const
