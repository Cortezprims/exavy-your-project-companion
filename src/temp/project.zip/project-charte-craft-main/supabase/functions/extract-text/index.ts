import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { encode as encodeBase64 } from "https://deno.land/std@0.168.0/encoding/base64.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { documentId, fileUrl, fileType } = await req.json();
    console.log('Processing document:', documentId, 'type:', fileType);

    if (!documentId || !fileUrl) {
      throw new Error('documentId and fileUrl are required');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    let extractedContent = '';

    if (fileType === 'pdf') {
      // Use Lovable AI to extract text from PDF via description
      const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

      if (!LOVABLE_API_KEY) {
        throw new Error('LOVABLE_API_KEY not configured');
      }

      // Fetch the PDF file
      const pdfResponse = await fetch(fileUrl);
      if (!pdfResponse.ok) {
        throw new Error('Failed to fetch PDF');
      }

      const pdfBuffer = await pdfResponse.arrayBuffer();
      // IMPORTANT: avoid String.fromCharCode/apply to prevent call stack overflow on large files
      const pdfBase64 = encodeBase64(pdfBuffer);

      console.log('PDF size:', pdfBuffer.byteLength, 'bytes');

      // Use Gemini's vision capability to extract text from PDF
      const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${LOVABLE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'google/gemini-2.5-flash',
          messages: [
            {
              role: 'system',
              content: `Tu es un assistant spécialisé dans l'extraction de texte. Extrais et retourne TOUT le contenu textuel du document de manière structurée et complète. Préserve la structure du document (titres, paragraphes, listes). Ne fais aucun résumé, retourne le texte intégral.`
            },
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text: 'Extrais tout le texte de ce document PDF. Retourne le contenu textuel complet sans résumé.'
                },
                {
                  type: 'image_url',
                  image_url: {
                    url: `data:application/pdf;base64,${pdfBase64}`
                  }
                }
              ]
            }
          ],
          max_tokens: 16000,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('AI Gateway error:', response.status, errorText);

        if (response.status === 429) {
          throw new Error('Rate limit exceeded');
        }
        if (response.status === 402) {
          throw new Error('AI credits exhausted');
        }
        throw new Error(`AI Gateway error: ${response.status}`);
      }

      const data = await response.json();
      extractedContent = data.choices?.[0]?.message?.content || '';
      console.log('Extracted content length:', extractedContent.length);

    } else if (fileType === 'text') {
      // For text files, just fetch the content
      const textResponse = await fetch(fileUrl);
      extractedContent = await textResponse.text();
    } else if (fileType === 'image') {
      // Use Gemini vision for images
      const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

      if (!LOVABLE_API_KEY) {
        throw new Error('LOVABLE_API_KEY not configured');
      }

      const imageResponse = await fetch(fileUrl);
      const imageBuffer = await imageResponse.arrayBuffer();
      // IMPORTANT: avoid String.fromCharCode/apply to prevent call stack overflow on large files
      const imageBase64 = encodeBase64(imageBuffer);
      const contentType = imageResponse.headers.get('content-type') || 'image/jpeg';

      const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${LOVABLE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'google/gemini-2.5-flash',
          messages: [
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text: 'Extrais tout le texte visible dans cette image. Si c\'est un document scanné, retourne le texte complet. Sinon, décris le contenu de manière détaillée.'
                },
                {
                  type: 'image_url',
                  image_url: {
                    url: `data:${contentType};base64,${imageBase64}`
                  }
                }
              ]
            }
          ],
          max_tokens: 8000,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        extractedContent = data.choices?.[0]?.message?.content || '';
      }
    }

    // Update the document with extracted content
    const { error: updateError } = await supabase
      .from('documents')
      .update({
        extracted_content: extractedContent,
        processing_status: 'completed',
        updated_at: new Date().toISOString(),
      })
      .eq('id', documentId);

    if (updateError) {
      console.error('Database update error:', updateError);
      throw updateError;
    }

    console.log('Document updated successfully');

    return new Response(
      JSON.stringify({
        success: true,
        contentLength: extractedContent.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Extract text error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
